from pycocotools.coco import COCO
import torch
import os
import numpy as np
from detectron2.data import detection_utils as utils

tasks = {
    "voc": {
        "offline":
            {
                0: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
                1: [],
            },
        "15-5":
            {
                0: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
                1: [16, 17, 18, 19, 20]
            },
        "15-1":
            {
                0: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
                1: [16],
                2: [17],
                3: [18],
                4: [19],
                5: [20]
            },
        "5-0m":
            {
                0: [6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
                1: [1],
                2: [2],
                3: [3],
                4: [4],
                5: [5]
            },
        "5-0":
            {
                0: [6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
                1: [1, 2, 3, 4, 5]
            },
        "5-1":
            {
                0: [1, 2, 3, 4, 5, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
                1: [6, 7, 8, 9, 10]
            },
        "5-1m":
            {
                0: [1, 2, 3, 4, 5, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20],
                1: [6],
                2: [7],
                3: [8],
                4: [9],
                5: [10]
            },
        "5-2":
            {
                0: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 16, 17, 18, 19, 20],
                1: [11, 12, 13, 14, 15]
            },
        "5-2m":
            {
                0: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 16, 17, 18, 19, 20],
                1: [11],
                2: [12],
                3: [13],
                4: [14],
                5: [15]
            },
        "5-3":
            {
                0: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
                1: [16, 17, 18, 19, 20]
            },
        "5-3m":
            {
                0: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
                1: [16],
                2: [17],
                3: [18],
                4: [19],
                5: [20]
            },
    },
    "cts": {
        "offline":
            {
                0: [7, 8, 11, 12, 13, 17, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 31, 32, 33],
            },
        "bv":
            {
                0: [7, 8, 11, 12, 13, 17, 19, 20, 21, 22, 23, 24, 25, 26, 32, 33],
                1: [27, 28, 29, 30, 31]
            },
    },
    "coco": {
        "offline":
            {
                0: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 28, 31,
                    32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57,
                    58, 59, 60, 61, 62, 63, 64, 65, 67, 70, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 84, 85, 86, 87,
                    88, 89, 90],
            },
        "voc":
            {
                0: [1, 8, 10, 11, 13, 14, 15, 22, 23, 24, 25, 27, 28, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42,
                    43, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 65, 70, 73, 74, 75, 76, 77, 78,
                    79, 80, 81, 82, 84, 85, 86, 87, 88, 89, 90],  # 53589 train img
                1: [2, 3, 4, 5, 6, 7, 9, 16, 17, 18, 19, 20, 21, 44, 62, 63, 64, 67, 72]  # voc classes w/out person
            },
        "7ss":
            {
                0: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17, 18, 19, 20, 22, 23, 24, 27, 28, 31, 32, 35,
                    36, 37, 38, 39, 40, 42, 43, 44, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 58, 59, 60, 61, 62, 63,
                    64, 65, 67, 70, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 84, 85, 86, 88, 89, 90],
                1: [21, 25, 33, 34, 41, 57, 87]
            },
        "7mc":
            {
                0: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17, 18, 19, 20, 22, 23, 24, 27, 28, 31, 32, 35,
                    36, 37, 38, 39, 40, 42, 43, 44, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 58, 59, 60, 61, 62, 63,
                    64, 65, 67, 70, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 84, 85, 86, 88, 89, 90],
                1: [21],
                2: [25],
                3: [33],
                4: [34],
                5: [41],
                6: [57],
                7: [87]
            },
        "20-0":
            {
                0: [2, 3, 4, 6, 7, 8, 10, 11, 13, 15, 16, 17, 19, 20, 21, 23, 24,
                    25, 28, 31, 32, 34, 35, 36, 38, 39, 40, 42, 43, 44, 47, 48, 49, 51,
                    52, 53, 55, 56, 57, 59, 60, 61, 63, 64, 65, 70, 72, 73, 75, 76, 77,
                    79, 80, 81, 84, 85, 86, 88, 89, 90],
                1: [1, 5, 9, 14, 18, 22, 27, 33, 37, 41, 46, 50, 54, 58, 62, 67, 74, 78, 82, 87]
            },
        "20-0m":
            {
                0: [2, 3, 4, 6, 7, 8, 10, 11, 13, 15, 16, 17, 19, 20, 21, 23, 24,
                    25, 28, 31, 32, 34, 35, 36, 38, 39, 40, 42, 43, 44, 47, 48, 49, 51,
                    52, 53, 55, 56, 57, 59, 60, 61, 63, 64, 65, 70, 72, 73, 75, 76, 77,
                    79, 80, 81, 84, 85, 86, 88, 89, 90],
                1: [1, 5, 9, 14, 18],
                2: [22, 27, 33, 37, 41],
                3: [46, 50, 54, 58, 62],
                4: [67, 74, 78, 82, 87]
            },
        "20-1":
            {
                0: [1, 3, 4, 5, 7, 8, 9, 11, 13, 14, 16, 17, 18, 20, 21, 22, 24,
                    25, 27, 31, 32, 33, 35, 36, 37, 39, 40, 41, 43, 44, 46, 48, 49, 50,
                    52, 53, 54, 56, 57, 58, 60, 61, 62, 64, 65, 67, 72, 73, 74, 76, 77,
                    78, 80, 81, 82, 85, 86, 87, 89, 90],
                1: [2, 6, 10, 15, 19, 23, 28, 34, 38, 42, 47, 51, 55, 59, 63, 70, 75, 79, 84, 88]
            },
        "20-1m":
            {
                0: [1, 3, 4, 5, 7, 8, 9, 11, 13, 14, 16, 17, 18, 20, 21, 22, 24,
                    25, 27, 31, 32, 33, 35, 36, 37, 39, 40, 41, 43, 44, 46, 48, 49, 50,
                    52, 53, 54, 56, 57, 58, 60, 61, 62, 64, 65, 67, 72, 73, 74, 76, 77,
                    78, 80, 81, 82, 85, 86, 87, 89, 90],
                1: [2, 6, 10, 15, 19],
                2: [23, 28, 34, 38, 42],
                3: [47, 51, 55, 59, 63],
                4: [70, 75, 79, 84, 88]
            },
        "20-2":
            {
                0: [1, 2, 4, 5, 6, 8, 9, 10, 13, 14, 15, 17, 18, 19, 21, 22, 23,
                    25, 27, 28, 32, 33, 34, 36, 37, 38, 40, 41, 42, 44, 46, 47, 49, 50,
                    51, 53, 54, 55, 57, 58, 59, 61, 62, 63, 65, 67, 70, 73, 74, 75, 77,
                    78, 79, 81, 82, 84, 86, 87, 88, 90],
                1: [3, 7, 11, 16, 20, 24, 31, 35, 39, 43, 48, 52, 56, 60, 64, 72, 76, 80, 85, 89]
            },
        "20-2m":
            {
                0: [1, 2, 4, 5, 6, 8, 9, 10, 13, 14, 15, 17, 18, 19, 21, 22, 23,
                    25, 27, 28, 32, 33, 34, 36, 37, 38, 40, 41, 42, 44, 46, 47, 49, 50,
                    51, 53, 54, 55, 57, 58, 59, 61, 62, 63, 65, 67, 70, 73, 74, 75, 77,
                    78, 79, 81, 82, 84, 86, 87, 88, 90],
                1: [3, 7, 11, 16, 20],
                2: [24, 31, 35, 39, 43],
                3: [48, 52, 56, 60, 64],
                4: [72, 76, 80, 85, 89]
            },
        "20-3":
            {
                0: [1, 2, 3, 5, 6, 7, 9, 10, 11, 14, 15, 16, 18, 19, 20, 22, 23,
                    24, 27, 28, 31, 33, 34, 35, 37, 38, 39, 41, 42, 43, 46, 47, 48, 50,
                    51, 52, 54, 55, 56, 58, 59, 60, 62, 63, 64, 67, 70, 72, 74, 75, 76,
                    78, 79, 80, 82, 84, 85, 87, 88, 89],
                1: [4, 8, 13, 17, 21, 25, 32, 36, 40, 44, 49, 53, 57, 61, 65, 73, 77, 81, 86, 90]
            },
        "20-3m":
            {
                0: [1, 2, 3, 5, 6, 7, 9, 10, 11, 14, 15, 16, 18, 19, 20, 22, 23,
                    24, 27, 28, 31, 33, 34, 35, 37, 38, 39, 41, 42, 43, 46, 47, 48, 50,
                    51, 52, 54, 55, 56, 58, 59, 60, 62, 63, 64, 67, 70, 72, 74, 75, 76,
                    78, 79, 80, 82, 84, 85, 87, 88, 89],
                1: [4, 8, 13, 17, 21],
                2: [25, 32, 36, 40, 44],
                3: [49, 53, 57, 61, 65],
                4: [73, 77, 81, 86, 90]
            },
    },

    "coco-stuff": {
        "offline":
            {
                0: list(range(1, 183)),
            },
        "spn":
            {  # labels are remapped according to http://github.com/nightrome/cocostuff/blob/master/labels.md
                0: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17, 18, 19, 20, 22, 23, 24, 27, 28, 31, 32, 35,
                    36, 37, 38, 39, 40, 42, 43, 44, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 58, 59, 60, 61, 62, 63,
                    64, 65, 67, 70, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 84, 85, 86, 88, 89, 90, 92, 93, 94, 95,
                    96, 97, 98, 99, 101, 102, 103, 104, 105, 107, 108, 109, 110, 111, 112, 113, 114, 115, 116, 117, 118,
                    119, 120, 121, 122, 123, 125, 126, 127, 128, 129, 130, 131, 132, 133, 134, 135, 136, 137, 138, 139,
                    140, 141, 142, 143, 144, 146, 147, 150, 151, 152, 153, 154, 155, 156, 157, 158, 159, 160, 161, 162,
                    163, 164, 165, 166, 167, 168, 170, 171, 173, 174, 175, 176, 177, 178, 179, 180, 181, 182],  # 156 cl
                1: [21, 25, 33, 34, 41, 57, 87, 100, 106, 124, 145, 148, 149, 169, 172]  # 15 cl not in ImageNet
            }
    }
}

# prepare train dataset

# coco = COCO('../data/coco/annotations/instances_train2017.json')
coco = None

def containNovel(novelCats, imgId):
    catIds = coco.getImgIds(imgIds=[imgId])
    tmp = set(novelCats) & set(catIds)
    if len(tmp) != 0:
        return True
    else:
        return False

def prepare_coco(task):
    coco = COCO('../data/coco/annotations/instances_train2017.json')
    assert task in tasks["coco"].keys(), f"You should provide a valid task name! [{task} is out of range]"

    coco_ids = coco.getCatIds()
    mapper = {coco_ids[a - 1] : a for a in range(1, 81)}    # cocoId -> continualId
    baseCats = tasks["coco"][task][0]
    novelCats = tasks["coco"][task][1]
    novelImgs = set()
    for cls in novelCats:
        for imgId in coco.getImgIds(catIds=[cls]):
            novelImgs.add(imgId)

    print(len(novelImgs))

    # base step
    sub_class_file_list = {}
    for cls in baseCats:
        sub_class_file_list[mapper[cls]] = []

    image_label_list = set()
    for cls in baseCats:
        for imgId in coco.getImgIds(catIds=[cls]):
            if not imgId in novelImgs:
                info = (f'train2017/{imgId:0>12}.jpg', f'annotations/coco_masks/instance_train2017/{imgId:0>12}.png')
                image_label_list.add(info)
                sub_class_file_list[mapper[cls]].append(info)
    content = [image_label_list, sub_class_file_list]
    d = f'./coco/{task}/train_step0.pth'
    print(f"task {task} base step {len(image_label_list)}")
    torch.save(content, d)

    # novel step
    image_label_list = set()
    sub_class_file_list = {}
    for cls in novelCats:
        sub_class_file_list[mapper[cls]] = []

    for cls in novelCats:
        for imgId in coco.getImgIds(catIds=[cls]):
            info = (f'train2017/{imgId:0>12}.jpg', f'annotations/coco_masks/instance_train2017/{imgId:0>12}.png')
            image_label_list.add(info)
            sub_class_file_list[mapper[cls]].append(info)
    content = [image_label_list, sub_class_file_list]
    d = f'./coco/{task}/train_step1.pth'
    torch.save(content, d)
    
    # prepare test dataset
    coco = COCO('../data/coco/annotations/instances_val2017.json')
    coco_ids = coco.getCatIds()
    mapper = {coco_ids[a - 1] : a for a in range(1, 81)}    # cocoId -> continualId
    image_label_list = set()
    sub_class_file_list = {}
    imgs = set()
    # for imgId in coco.getImgIds():
    #     image_label_list.add((f'val2017/{imgId:0>12}.jpg', f'annotations/coco_masks/instance_val2017/{imgId:0>12}.png'))
    for catId in coco.getCatIds():
        l = []
        for imgId in coco.getImgIds(catIds=[catId]):
            info = (f'val2017/{imgId:0>12}.jpg', f'annotations/coco_masks/instance_val2017/{imgId:0>12}.png')
            l.append(info)
            imgs.add(imgId)
            image_label_list.add(info)
        sub_class_file_list[mapper[catId]] = l
    d = f'valid.pth'
    content = [image_label_list, sub_class_file_list]
    if not os.path.exists(os.path.join('../list/coco', task)):
        os.mkdir(os.path.join('../list/coco', task))
    torch.save(content, os.path.join('../list/coco', task, d))
    print(len(imgs))


def prepare_voc(task):
    root = '/media/data/qxh/workspace/IFS-MaskFormer/data/voc/'

    if not os.path.exists(os.path.join('./voc', task)):
        os.mkdir(os.path.join('./voc', task))

    # train
    imgs = []
    gts = []
    with open(root + "/splits/train_aug.txt", "r") as f:
        lines = f.readlines()
    for line in lines:
        img, gt = line[:-1].split(" ")
        imgs.append(img[1:])
        gts.append(gt[1:])
    
    datas = {}
    for i in range(1, 21):
        datas[i] = []
    
    for img, gt in zip(imgs, gts):
        classes = np.unique(utils.read_image(root + gt).astype("int")).tolist()
        for cls in classes:
            if cls != 0 and cls != 255:
                datas[cls].append((img, gt))

    ## novel step
    base_cls = tasks["voc"][task][0]
    novel_cls = tasks["voc"][task][1]

    image_label_list = set()
    sub_class_file_list = {}

    for cls in novel_cls:
        image_label_list.update(datas[cls])
        sub_class_file_list[cls] = datas[cls]
        for data in datas[cls]:
            assert (data[0] in imgs) == (data[1] in gts), "Something is wrong!!!!!!!!"
            if data[0] in imgs and data[1] in gts:
                imgs.remove(data[0])
                gts.remove(data[1])
    
    assert len(imgs) == len(gts), "len of imgs should be equal to len of gts!"

    content = [image_label_list, sub_class_file_list]
    d = f'train_step1.pth'
    torch.save(content, os.path.join('./voc', task, d))

    ## base step
    image_label_list = set()
    for img, gt in zip(imgs, gts):
        image_label_list.add((img, gt))

    content = [image_label_list, {}]
    d = f'train_step0.pth'
    torch.save(content, os.path.join('./voc', task, d))

    # val
    imgs = []
    gts = []
    with open(root + "/splits/val.txt", "r") as f:
        lines = f.readlines()
    for line in lines:
        img, gt = line[:-1].split(" ")
        imgs.append(img[1:])
        gts.append(gt[1:])
    image_label_list = set()
    for img, gt in zip(imgs, gts):
        image_label_list.add((img, gt))
    content = [image_label_list, {}]
    d = f'valid.pth'
    torch.save(content, os.path.join('./voc', task, d))





# for task in ["20-0", "20-1", "20-2", "20-3"]:
#     prepare_coco(task)
        
# for task in ['5-0', '5-1', '5-2', '5-3']:
#     prepare_voc(task)

prepare_voc("offline")